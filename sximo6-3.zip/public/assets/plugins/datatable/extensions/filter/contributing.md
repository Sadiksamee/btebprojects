Question should be asked on stackoverflow and tagged with yadcf - http://stackoverflow.com/questions/tagged/yadcf

Use github for bug reports or new features request only

In case of bug always post a code sample that resembles your issue or event better provide a link to your page